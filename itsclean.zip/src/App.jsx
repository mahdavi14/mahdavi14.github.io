
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingCart, Menu, X, Star, MapPin, Phone, Mail, Instagram, Facebook, Twitter, ChevronLeft, ChevronRight, Plus, Minus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Toaster } from '@/components/ui/toaster';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [cart, setCart] = useState([]);
  const [cartCount, setCartCount] = useState(0);
  const { toast } = useToast();

  const banners = [
    {
      id: 1,
      title: "Promo Spesial Akhir Tahun!",
      subtitle: "Diskon hingga 50% untuk semua layanan cleaning sepatu",
      bgColor: "from-blue-600 to-purple-700"
    },
    {
      id: 2,
      title: "Paket Hemat Premium Care",
      subtitle: "Deep cleaning + waterproof protection hanya 75rb",
      bgColor: "from-green-600 to-teal-700"
    },
    {
      id: 3,
      title: "Gratis Pickup & Delivery",
      subtitle: "Untuk area Jakarta, Bogor, Depok, Tangerang, Bekasi",
      bgColor: "from-orange-600 to-red-700"
    }
  ];

  const services = [
    {
      id: 1,
      name: "Basic Cleaning",
      price: 25000,
      originalPrice: 35000,
      description: "Pembersihan dasar untuk sepatu harian",
      features: ["Pembersihan luar", "Pembersihan sol", "Pengeringan"]
    },
    {
      id: 2,
      name: "Deep Cleaning",
      price: 45000,
      originalPrice: 60000,
      description: "Pembersihan mendalam untuk sepatu kotor berat",
      features: ["Pembersihan dalam & luar", "Pembersihan sol detail", "Sanitasi", "Pengeringan premium"]
    },
    {
      id: 3,
      name: "Premium Care",
      price: 75000,
      originalPrice: 100000,
      description: "Perawatan lengkap dengan perlindungan waterproof",
      features: ["Deep cleaning", "Waterproof protection", "Conditioning", "Quality guarantee"]
    }
  ];

  const products = [
    {
      id: 1,
      name: "Shoe Cleaner Spray",
      price: 85000,
      originalPrice: 120000,
      rating: 4.8,
      reviews: 156,
      description: "Spray pembersih sepatu premium untuk perawatan harian"
    },
    {
      id: 2,
      name: "Waterproof Protection",
      price: 95000,
      originalPrice: 130000,
      rating: 4.9,
      reviews: 203,
      description: "Pelindung anti air untuk semua jenis sepatu"
    },
    {
      id: 3,
      name: "Cleaning Kit Complete",
      price: 150000,
      originalPrice: 200000,
      rating: 4.7,
      reviews: 89,
      description: "Paket lengkap perawatan sepatu di rumah"
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % banners.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [banners.length]);

  useEffect(() => {
    const total = cart.reduce((sum, item) => sum + item.quantity, 0);
    setCartCount(total);
  }, [cart]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % banners.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + banners.length) % banners.length);
  };

  const addToCart = (item, type = 'product') => {
    const cartItem = {
      id: `${type}-${item.id}`,
      name: item.name,
      price: item.price,
      type: type,
      quantity: 1
    };

    setCart(prev => {
      const existingItem = prev.find(cartItem => cartItem.id === `${type}-${item.id}`);
      if (existingItem) {
        return prev.map(cartItem => 
          cartItem.id === `${type}-${item.id}` 
            ? { ...cartItem, quantity: cartItem.quantity + 1 }
            : cartItem
        );
      }
      return [...prev, cartItem];
    });

    toast({
      title: "Ditambahkan ke keranjang!",
      description: `${item.name} berhasil ditambahkan`,
      duration: 2000,
    });
  };

  const updateCartQuantity = (id, change) => {
    setCart(prev => {
      return prev.map(item => {
        if (item.id === id) {
          const newQuantity = item.quantity + change;
          return newQuantity > 0 ? { ...item, quantity: newQuantity } : null;
        }
        return item;
      }).filter(Boolean);
    });
  };

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  const handleCheckout = () => {
    toast({
      title: "🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀",
      duration: 3000,
    });
  };

  const handleBookService = (service) => {
    toast({
      title: "🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀",
      duration: 3000,
    });
  };

  const handleContactClick = () => {
    toast({
      title: "🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀",
      duration: 3000,
    });
  };

  return (
    <>
      <Helmet>
        <title>IT'S CLEAN - Jasa & Produk Perawatan Sepatu Terbaik</title>
        <meta name="description" content="Layanan profesional cleaning sepatu dengan pickup gratis. Produk perawatan sepatu premium. Garansi kualitas terbaik di Jakarta." />
      </Helmet>

      <div className="max-w-4xl mx-auto bg-white min-h-screen">
        {/* Header */}
        <motion.header 
          initial={{ y: -100 }}
          animate={{ y: 0 }}
          className="bg-white shadow-lg sticky top-0 z-40"
        >
          <div className="px-4 py-3">
            <div className="flex items-center justify-between">
              <motion.div 
                whileHover={{ scale: 1.05 }}
                className="flex items-center space-x-2"
              >
                <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">IC</span>
                </div>
                <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  IT'S CLEAN
                </span>
              </motion.div>

              <div className="flex items-center space-x-4">
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setSelectedProduct('cart')}
                  className="relative p-2 text-slate-600 hover:text-blue-600 transition-colors"
                >
                  <ShoppingCart className="w-6 h-6" />
                  {cartCount > 0 && (
                    <motion.span
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center"
                    >
                      {cartCount}
                    </motion.span>
                  )}
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setIsMenuOpen(!isMenuOpen)}
                  className="p-2 text-slate-600 hover:text-blue-600 transition-colors"
                >
                  {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
                </motion.button>
              </div>
            </div>

            <AnimatePresence>
              {isMenuOpen && (
                <motion.nav
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="mt-4 overflow-hidden"
                >
                  <div className="space-y-2 pb-4">
                    {['Beranda', 'Layanan', 'Produk', 'Tentang', 'Kontak'].map((item) => (
                      <motion.a
                        key={item}
                        whileHover={{ x: 10 }}
                        href={`#${item.toLowerCase()}`}
                        className="block py-2 px-4 text-slate-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                        onClick={() => setIsMenuOpen(false)}
                      >
                        {item}
                      </motion.a>
                    ))}
                  </div>
                </motion.nav>
              )}
            </AnimatePresence>
          </div>
        </motion.header>

        {/* Banner Slider */}
        <section className="relative h-64 overflow-hidden">
          <div 
            className="banner-slider h-full"
            style={{ transform: `translateX(-${currentSlide * 100}%)` }}
          >
            {banners.map((banner, index) => (
              <div
                key={banner.id}
                className={`banner-slide h-full bg-gradient-to-r ${banner.bgColor} flex items-center justify-center text-white relative`}
              >
                <div className="text-center px-6">
                  <motion.h2
                    initial={{ y: 50, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.2 }}
                    className="text-2xl md:text-3xl font-bold mb-2"
                  >
                    {banner.title}
                  </motion.h2>
                  <motion.p
                    initial={{ y: 50, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.4 }}
                    className="text-lg opacity-90"
                  >
                    {banner.subtitle}
                  </motion.p>
                </div>
              </div>
            ))}
          </div>

          <button
            onClick={prevSlide}
            className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/20 hover:bg-white/30 text-white p-2 rounded-full transition-all"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={nextSlide}
            className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/20 hover:bg-white/30 text-white p-2 rounded-full transition-all"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
            {banners.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-3 h-3 rounded-full transition-all ${
                  index === currentSlide ? 'bg-white' : 'bg-white/50'
                }`}
              />
            ))}
          </div>
        </section>

        {/* Services Section */}
        <section id="layanan" className="py-12 px-6 bg-gradient-to-br from-slate-50 to-blue-50">
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mb-10"
          >
            <h2 className="text-3xl font-bold text-slate-800 mb-4">Layanan Kami</h2>
            <p className="text-slate-600 max-w-2xl mx-auto">
              Pilih paket perawatan sepatu yang sesuai dengan kebutuhan Anda
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {services.map((service, index) => (
              <motion.div
                key={service.id}
                initial={{ y: 50, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -10, scale: 1.02 }}
                className="bg-white rounded-2xl shadow-lg p-6 border border-slate-100 hover:shadow-xl transition-all duration-300"
              >
                <div className="text-center mb-6">
                  <h3 className="text-xl font-bold text-slate-800 mb-2">{service.name}</h3>
                  <p className="text-slate-600 text-sm mb-4">{service.description}</p>
                  
                  <div className="flex items-center justify-center space-x-2 mb-4">
                    <span className="text-2xl font-bold text-blue-600">
                      Rp {service.price.toLocaleString()}
                    </span>
                    <span className="text-lg price-strikethrough">
                      Rp {service.originalPrice.toLocaleString()}
                    </span>
                  </div>

                  <div className="space-y-2 mb-6">
                    {service.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center justify-center text-sm text-slate-600">
                        <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                        {feature}
                      </div>
                    ))}
                  </div>

                  <Button
                    onClick={() => handleBookService(service)}
                    className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold py-3 rounded-xl transition-all duration-300"
                  >
                    Pesan Sekarang
                  </Button>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Products Section */}
        <section id="produk" className="py-12 px-6">
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mb-10"
          >
            <h2 className="text-3xl font-bold text-slate-800 mb-4">Produk Perawatan</h2>
            <p className="text-slate-600 max-w-2xl mx-auto">
              Produk berkualitas tinggi untuk perawatan sepatu di rumah
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {products.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ y: 50, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -10, scale: 1.02 }}
                className="bg-white rounded-2xl shadow-lg overflow-hidden border border-slate-100 hover:shadow-xl transition-all duration-300"
              >
                <div className="h-48 bg-gradient-to-br from-slate-100 to-slate-200 flex items-center justify-center">
                  <img  
                    alt={`${product.name} - produk perawatan sepatu premium`}
                    className="w-32 h-32 object-cover rounded-lg"
                   src="https://images.unsplash.com/photo-1618349248372-afb74754b087" />
                </div>

                <div className="p-6">
                  <h3 className="text-lg font-bold text-slate-800 mb-2">{product.name}</h3>
                  <p className="text-slate-600 text-sm mb-3">{product.description}</p>

                  <div className="flex items-center mb-3">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < Math.floor(product.rating) ? 'text-yellow-400 fill-current' : 'text-slate-300'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-slate-600 ml-2">
                      {product.rating} ({product.reviews} ulasan)
                    </span>
                  </div>

                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-2">
                      <span className="text-xl font-bold text-blue-600">
                        Rp {product.price.toLocaleString()}
                      </span>
                      <span className="text-sm price-strikethrough">
                        Rp {product.originalPrice.toLocaleString()}
                      </span>
                    </div>
                  </div>

                  <Button
                    onClick={() => addToCart(product, 'product')}
                    className="w-full bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700 text-white font-semibold py-3 rounded-xl transition-all duration-300"
                  >
                    Tambah ke Keranjang
                  </Button>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* About Section */}
        <section id="tentang" className="py-12 px-6 bg-gradient-to-br from-blue-50 to-purple-50">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl font-bold text-slate-800 mb-6">Tentang IT'S CLEAN</h2>
              <p className="text-lg text-slate-600 mb-8 leading-relaxed">
                IT'S CLEAN adalah layanan profesional perawatan sepatu yang telah dipercaya ribuan pelanggan. 
                Dengan teknologi cleaning terdepan dan produk berkualitas premium, kami memberikan hasil terbaik 
                untuk sepatu kesayangan Anda.
              </p>
              
              <div className="grid md:grid-cols-3 gap-8 mt-12">
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  className="text-center"
                >
                  <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-white text-2xl font-bold">5+</span>
                  </div>
                  <h3 className="text-xl font-bold text-slate-800 mb-2">Tahun Pengalaman</h3>
                  <p className="text-slate-600">Melayani dengan dedikasi tinggi</p>
                </motion.div>

                <motion.div
                  whileHover={{ scale: 1.05 }}
                  className="text-center"
                >
                  <div className="w-16 h-16 bg-gradient-to-r from-green-600 to-teal-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-white text-2xl font-bold">10K+</span>
                  </div>
                  <h3 className="text-xl font-bold text-slate-800 mb-2">Sepatu Dibersihkan</h3>
                  <p className="text-slate-600">Kepercayaan pelanggan setia</p>
                </motion.div>

                <motion.div
                  whileHover={{ scale: 1.05 }}
                  className="text-center"
                >
                  <div className="w-16 h-16 bg-gradient-to-r from-orange-600 to-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-white text-2xl font-bold">24/7</span>
                  </div>
                  <h3 className="text-xl font-bold text-slate-800 mb-2">Layanan Konsultasi</h3>
                  <p className="text-slate-600">Siap membantu kapan saja</p>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="kontak" className="py-12 px-6">
          <div className="max-w-4xl mx-auto">
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              className="text-center mb-10"
            >
              <h2 className="text-3xl font-bold text-slate-800 mb-4">Hubungi Kami</h2>
              <p className="text-slate-600">Siap melayani Anda dengan sepenuh hati</p>
            </motion.div>

            <div className="grid md:grid-cols-2 gap-8">
              <motion.div
                initial={{ x: -50, opacity: 0 }}
                whileInView={{ x: 0, opacity: 1 }}
                viewport={{ once: true }}
                className="space-y-6"
              >
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                    <MapPin className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-800">Alamat</h3>
                    <p className="text-slate-600">Jl. Sudirman No. 123, Jakarta Pusat</p>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-green-600 to-teal-600 rounded-full flex items-center justify-center">
                    <Phone className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-800">Telepon</h3>
                    <p className="text-slate-600">+62 812-3456-7890</p>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-orange-600 to-red-600 rounded-full flex items-center justify-center">
                    <Mail className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-800">Email</h3>
                    <p className="text-slate-600">info@itsclean.id</p>
                  </div>
                </div>

                <div className="flex space-x-4 pt-4">
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={handleContactClick}
                    className="w-12 h-12 bg-gradient-to-r from-pink-600 to-purple-600 rounded-full flex items-center justify-center"
                  >
                    <Instagram className="w-6 h-6 text-white" />
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={handleContactClick}
                    className="w-12 h-12 bg-gradient-to-r from-blue-600 to-blue-700 rounded-full flex items-center justify-center"
                  >
                    <Facebook className="w-6 h-6 text-white" />
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={handleContactClick}
                    className="w-12 h-12 bg-gradient-to-r from-sky-600 to-blue-600 rounded-full flex items-center justify-center"
                  >
                    <Twitter className="w-6 h-6 text-white" />
                  </motion.button>
                </div>
              </motion.div>

              <motion.div
                initial={{ x: 50, opacity: 0 }}
                whileInView={{ x: 0, opacity: 1 }}
                viewport={{ once: true }}
                className="bg-white rounded-2xl shadow-lg p-6 border border-slate-100"
              >
                <h3 className="text-xl font-bold text-slate-800 mb-4">Kirim Pesan</h3>
                <form className="space-y-4">
                  <input
                    type="text"
                    placeholder="Nama Anda"
                    className="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                  />
                  <input
                    type="email"
                    placeholder="Email Anda"
                    className="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                  />
                  <textarea
                    placeholder="Pesan Anda"
                    rows="4"
                    className="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all resize-none"
                  ></textarea>
                  <Button
                    type="button"
                    onClick={handleContactClick}
                    className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold py-3 rounded-xl transition-all duration-300"
                  >
                    Kirim Pesan
                  </Button>
                </form>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-slate-800 text-white py-8 px-6">
          <div className="max-w-4xl mx-auto text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">IC</span>
              </div>
              <span className="text-xl font-bold">IT'S CLEAN</span>
            </div>
            <p className="text-slate-400 mb-4">
              Perawatan sepatu profesional dengan kualitas terbaik
            </p>
            <p className="text-slate-500 text-sm">
              © 2024 IT'S CLEAN. Semua hak dilindungi.
            </p>
          </div>
        </footer>

        {/* Cart Modal */}
        <AnimatePresence>
          {selectedProduct === 'cart' && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
              onClick={() => setSelectedProduct(null)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="bg-white rounded-2xl p-6 max-w-md w-full max-h-[80vh] overflow-y-auto"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-slate-800">Keranjang Belanja</h2>
                  <button
                    onClick={() => setSelectedProduct(null)}
                    className="p-2 hover:bg-slate-100 rounded-full transition-colors"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                {cart.length === 0 ? (
                  <div className="text-center py-8">
                    <ShoppingCart className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                    <p className="text-slate-600">Keranjang Anda kosong</p>
                  </div>
                ) : (
                  <>
                    <div className="space-y-4 mb-6">
                      {cart.map((item) => (
                        <div key={item.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-xl">
                          <div className="flex-1">
                            <h3 className="font-semibold text-slate-800">{item.name}</h3>
                            <p className="text-blue-600 font-semibold">Rp {item.price.toLocaleString()}</p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <button
                              onClick={() => updateCartQuantity(item.id, -1)}
                              className="w-8 h-8 bg-slate-200 hover:bg-slate-300 rounded-full flex items-center justify-center transition-colors"
                            >
                              <Minus className="w-4 h-4" />
                            </button>
                            <span className="w-8 text-center font-semibold">{item.quantity}</span>
                            <button
                              onClick={() => updateCartQuantity(item.id, 1)}
                              className="w-8 h-8 bg-slate-200 hover:bg-slate-300 rounded-full flex items-center justify-center transition-colors"
                            >
                              <Plus className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="border-t pt-4">
                      <div className="flex items-center justify-between mb-4">
                        <span className="text-lg font-semibold text-slate-800">Total:</span>
                        <span className="text-2xl font-bold text-blue-600">
                          Rp {getTotalPrice().toLocaleString()}
                        </span>
                      </div>
                      <Button
                        onClick={handleCheckout}
                        className="w-full bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700 text-white font-semibold py-3 rounded-xl transition-all duration-300"
                      >
                        Checkout
                      </Button>
                    </div>
                  </>
                )}
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        <Toaster />
      </div>
    </>
  );
}

export default App;
